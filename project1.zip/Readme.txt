Copyright: 2018, Fengxiang Lan & Jing Zhang

Environment: Windos 10; python3 interpreter (version 3.6.5).

Documents: there are three documents, 'PartI.py' is for basic TTT, 'PartII.py' is for advanced TTT, 'PartIII.py' is for ultimate TTT.

Steps for running the programs:
1)Open terminal under the path of tic-tac-toe programs.
2)Run the code with command line, 'python3  filename.py'
3)You will see a alert that is "Which player do you want to choose, 'x' or 'o': " You need to input 'x' or 'o'.
4)Then the game begins and you will need to input your moves following the instrucions.
5) If you enter the right number, if will show the board which has the chess you had put.
6) Each time the computer or you make a move, the current state will be printed on the screen. After the game is over, the final result will be shown. 


